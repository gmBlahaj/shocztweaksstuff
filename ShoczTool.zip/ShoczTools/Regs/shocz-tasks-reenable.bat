@echo off
mkdir "C:\WINDOWS\System32\Tasks\Microsoft\Windows"
exit