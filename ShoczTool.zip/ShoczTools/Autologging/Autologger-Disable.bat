@echo off
title Shocz Autologger Disable
color 9

:: Check for Autologger Log Folder.
if not exist "C:\Logs" (
   mkdir "C:\Logs" >nul 2>&1
   call :Autologger_Disabler_Log_Start
   echo [%DATE% %TIME%] Autologger Disabler Log Folder Check: Folder Created. >> "C:\Logs\Autologger Disabler Log.txt"
) else (
   call :Autologger_Disabler_Log_Start
   echo [%DATE% %TIME%] Autologger Disabler Log Folder Check: Folder already exist. >> "C:\Logs\Autologger Disabler Log.txt"
)


:: Check for Autologger Disabler Backup Folder. (Checks if the backup folder exists to avoid overwriting existing backups)
if not exist "C:\Shocz Tools\Backup\Backup\Autologger Disabler" (
   mkdir "C:\Shocz Tools\Backup\Backup\Autologger Disabler" >nul 2>&1
   set "Autologger_Disabler_Backup_Folder=C:\Shocz Tools\Backup\Backup\Autologger Disabler"
   call echo [%DATE% %TIME%] Autologger Disabler Backup Folder Check: Folder doesn't exist - "%%Autologger_Disabler_Backup_Folder%%" Created. >> "C:\Logs\Autologger Disabler Log.txt"
) else (
   for /f "usebackq delims=" %%A in (`Powershell -NoProfile -Command "Get-Date -Format 'MM-dd-yyyy_HH-mm'"`) do set "CurrentDate=%%A"
   call set "Autologger_Disabler_Backup_Folder=C:\Autologger Disabler Backup [%%CurrentDate%%]"
   call mkdir "%%Autologger_Disabler_Backup_Folder%%" >nul 2>&1
   call echo [%DATE% %TIME%] Autologger Disabler Backup Folder Check: Folder already exists - "%%Autologger_Disabler_Backup_Folder%%" Created. >> "C:\Logs\Autologger Disabler Log.txt"
)

:: Creating Autologger Reg Backup.
reg export "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger" "%Autologger_Disabler_Backup_Folder%\AutologgerBackup.reg" /y >nul 2>&1
if errorlevel 1 (
    echo [%DATE% %TIME%] Autologger Reg Key: Failed to create. >> "C:\Logs\Autologger Disabler Log.txt"
    goto :Winver_Check
    exit
) else ( 
    echo [%DATE% %TIME%] Autologger Reg Key: Created successfully. >> "C:\Logs\Autologger Disabler Log.txt"
    goto :Winver_Check
)

:: Check for Windows Version.
:Winver_Check
setlocal enabledelayedexpansion
for /f "tokens=3" %%A in ('reg query "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion" /v CurrentBuild') do set CurrentBuild=%%A
   echo [%DATE% %TIME%] Windows Version Detected: !CurrentBuild! >> "C:\Logs\Autologger Disabler Log.txt"
if !CurrentBuild! GEQ 22000 (
   echo [%DATE% %TIME%] Windows Version: 11+ >> "C:\Logs\Autologger Disabler Log.txt"
   goto :Autologger_Disabler_Start_Screen
) else (
   echo [%DATE% %TIME%] Windows Version: 10. - Disabling EventLog-Application and EventLog-System. >> "C:\Logs\Autologger Disabler Log.txt"
   reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\EventLog-Application" /v "Start" /t REG_DWORD /d "0" /f >nul 2>&1
   reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\EventLog-System" /v "Start" /t REG_DWORD /d "0" /f >nul 2>&1
   goto :Autologger_Disabler_Start_Screen
)
endlocal

:: Autologger Disabler Menu.
:Autologger_Disabler_Start_Screen
cls
color 9
chcp 65001 >nul 2>&1
echo ╔═════════════════════════════╗
echo ║ ✅ Disable All Autologgers. ║
echo ╚═════════════════════════════╝

:: Disable Autologgers
for %%A in (
    "Cellcore"
    "CimFSUnionFS-Filter"
    "Circular Kernel Context Logger"
    "CloudExperienceHostOobe" 
    "DefenderApiLogger" 
    "DefenderAuditLogger" 
    "DiagLog" 
    "Diagtrack-Listener"
    "EventLog-Security"
    "FilterMgr-Logger"
    "FaceTel" 
    "LwtNetLog" 
    "Mellanox-Kernel" 
    "Microsoft-Windows-Rdp-Graphics-RdpIdd-Trace" 
    "Microsoft-Windows-Setup" 
    "NBSMBLOGGER" 
    "NetCore" 
    "NtfsLog" 
    "PEAuthLog" 
    "RadioMgr" 
    "RdrLog" 
    "ReadyBoot" 
    "ReFSLog" 
    "SetupPlatform" 
    "SetupPlatformTel" 
    "SpoolerLogger" 
    "SQMLogger" 
    "TCPIPLOGGER" 
    "TileStore" 
    "UBPM" 
    "WdiContextLog" 
    "WFP-IPsec Trace" 
    "WiFiDriverIHVSession" 
    "WiFiDriverIHVSessionRepro" 
    "WiFiSession" 
    "WMI_Traces" 
) do (
    reg query "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\%%~A" >nul 2>&1
    if not errorlevel 1 (
        reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\%%~A" /v "Start" /t REG_DWORD /d "0" /f >nul 2>&1
        echo [%DATE% %TIME%] Disabled: %%~A. >> "C:\Logs\Autologger Disabler Log.txt"
        echo • Disabled %%~A.
    )
)
pause
call :Autologger_Disabler_Log_End
exit

:: Autologger Disabler Logging Start. (The starting log of Autologger Disabler + Log Header)
:Autologger_Disabler_Log_Start
>> "C:\Logs\Autologger Disabler Log.txt" 2>&1 (
echo [%DATE% %TIME%] Autologger Disabler Started.
)
exit /b

:: Autologger Disabler Logging End. (The end log of Autologger Disabler)
:Autologger_Disabler_Log_End
>> "C:\Logs\Autologger Disabler Log.txt" 2>&1 (
echo [%DATE% %TIME%] Autologger Disabler Ended.
echo ________________________________________________________________ 
echo. 
)
exit /b

