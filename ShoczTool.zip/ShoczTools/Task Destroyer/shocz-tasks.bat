@echo off

:: Start Log.
echo [%DATE% %TIME%] Task Destroyer: Successfully started. >> "C:\Logs\Log.txt"

:: Creating Reg Backup.
echo [%DATE% %TIME%] Task Destroyer: Creating TaskSchedulerBackup.reg >> "C:\Logs\Log.txt"
reg export "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tree" "C:\Shocz Tools\Task Destroyer\Reg Backup\TaskSchedulerBackup.reg" /y >nul 2>&1
if errorlevel 1 (
    echo [%DATE% %TIME%] Task Destroyer Reg Backup: Failed to create. >> "C:\Logs\Log.txt"
) else ( 
    echo [%DATE% %TIME%] Task Destroyer Reg Backup: Created successfully. >> "C:\Logs\Log.txt"
)

:: Creating Task Backup.
echo [%DATE% %TIME%] Task Destroyer: Creating task file backup. >> "C:\Logs\Log.txt"
xcopy "C:\WINDOWS\System32\Tasks" "C:\Shocz Tools\Task Destroyer\Task Backup\Tasks" /E /I /H /Y >nul 2>&1
if errorlevel 1 (
    echo [%DATE% %TIME%] Task Destroyer: Task file backup failed to copy. >> "C:\Logs\Log.txt"
) else ( 
    echo [%DATE% %TIME%] Task Destroyer: Task file backup copied successfully. >> "C:\Logs\Log.txt" 
)

:: Delete All Task.
echo [%DATE% %TIME%] Task Destroyer: Deleting all task in Task Scheduler. >> "C:\Logs\Log.txt" 
reg delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskStateFlags" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache" /f >nul 2>&1

:: Delete System32 Task Folder.
echo [%DATE% %TIME%] Task Destroyer: Deleting System32 task folder. >> "C:\Logs\Log.txt" 
rd /s /q "C:\WINDOWS\System32\Tasks" >nul 2>&1

:: End Log.
echo [%DATE% %TIME%] Task Destroyer: Successfully Ended. >> "C:\Logs\Log.txt"





